# StockPro — Complete Full-Stack Trading Simulator

This folder contains the complete backend, frontend and persistent local database configuration.

## Technology choices
- Java 21
- Spring Boot 3.5.7
- Spring Web / REST API
- Spring Data JPA
- H2 file database (persists data between restarts)
- HTML, CSS and JavaScript
- Lightweight Charts for interactive candlestick charts

## Run on Windows
1. Install Java 21 and Maven.
2. Extract this ZIP.
3. In VS Code, choose **File → Open Folder** and open the extracted `StockPro_Full_App` folder.
4. Confirm `pom.xml` is directly visible in the VS Code Explorer.
5. Open **Terminal → New Terminal**.
6. Run:
   ```powershell
   mvn spring-boot:run
   ```
7. Open http://localhost:8080

You can also double-click `run-stockpro.bat` after Maven is installed.

## Database
StockPro uses an embedded H2 database stored at:
`./data/stockprodb.mv.db`

Stocks, wallet balance, holdings and trade transactions persist when the app is stopped and restarted. The simulated tick/candle history and in-browser indicator observation history are runtime data and reset when the app restarts or browser reloads.

H2 console:
- URL: http://localhost:8080/h2-console
- JDBC URL: `jdbc:h2:file:./data/stockprodb`
- User: `sa`
- Password: leave blank

If the H2 console is not needed, you can disable it in `application.properties`.

## Features
- Dashboard and watchlist
- Stock search and stock details
- Simulated prices refreshed every 3 seconds
- Candlestick chart with 1m, 5m, 15m, 1h and 1D aggregation
- RSI, MACD, SMA, Bollinger Bands and simulated-volume VWAP
- Rule-based BUY / SELL / HOLD signal and indicator agreement score
- Virtual wallet, buy and sell
- Portfolio and transaction history
- Responsive mobile layout

## REST API
- `GET /api/stocks`
- `GET /api/stocks/{symbol}`
- `GET /api/stocks/{symbol}/candles?timeframe=1m`
- `GET /api/dashboard`
- `GET /api/portfolio`
- `GET /api/trading/transactions`
- `POST /api/trading/buy?symbol=TCS&quantity=1`
- `POST /api/trading/sell?symbol=TCS&quantity=1`

## Important
This is an educational paper-trading simulator only. Prices are randomly simulated and are not live NSE/BSE prices. Candle intervals aggregate simulated observations, not exchange historical candles. VWAP uses simulated random volume. BUY/SELL/HOLD signals are simple rules, not predictions or probabilities of profit. No real broker, exchange, deposits, withdrawals or real-money trading is connected.
